﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class FerrariEngine : AbstractEngine
    {
        public FerrariEngine()
        {
            max_speed = 300;
        }
    }
}
